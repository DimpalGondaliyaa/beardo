<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="msapplication-tap-highlight" content="no">
    <title><?php echo $pageTitle; ?></title>
    <!-- CSS-->
    <link href="<?php echo base_url(); ?>html/css/style.css" rel="stylesheet">
    <link href="http://fonts.googleapis.com/css?family=Inconsolata" rel="stylesheet" type="text/css">
    <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <script src="http://code.jquery.com/jquery-3.2.1.min.js"></script>


    <!-- Compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0-beta/css/materialize.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">

    <!-- Compiled and minified JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0-beta/js/materialize.min.js"></script>


    <script src="<?php echo base_url(); ?>html/js/script.js"></script>

      <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/wow/0.1.12/wow.min.js"></script>
    <link rel="stylesheet" type="text/css" href="https://daneden.github.io/animate.css/animate.min.css">

    <?php foreach($stylesheet as $fileName){ ?>
    <link href="<?php echo base_url(); ?>html/css/<?php echo $fileName; ?>" rel="stylesheet">
    <?php } ?>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
</head>

<?php 
  $c = $this->db->query("select * from category_one");
  $cc = $c->result_array();
?>

<div class="row herow">
     <nav class="henav">
        <div class="nav-wrapper henavwrap">
          <a href="<?php echo base_url(); ?>home" class="brand-logo" ><img src="<?php echo base_url(); ?>html/images/li.png"> </a>
          <ul id="nav-mobile" class="right hide-on-med-and-down heul">
            <?php foreach ($cc as $key => $cat1) { ?>
            <li><a href="#" id="productsa"><?php echo $cat1['category_name']; ?></a></li>
            <?php } ?>
            <li><a href="collapsible.html">community</a></li>
            <li><a href="collapsible.html">merchandise</a></li>
            <li><a href="#"><i class="large material-icons">shopping_cart</i></a></li>
          </ul>
        </div>
     </nav>
</div>

<!--=================================================product part==========================-->
<div class="products" id="products" >
    <div class="row">
          <div class="col s6 m2">
            <div class="probox">
                <div class="proimg">
                    <img src="<?php echo base_url(); ?>html/images/products/hear-serum.jpg">
                </div>
                <div class="protitle hedbtn btn btn-1 btn-effect-1" data-direction="left">
                    <a href="<?php echo base_url(); ?>Category_List"><span>HAIR</span></a>
                </div>
            </div>
          </div>

           <div class="col s6 m2">
            <div class="probox">
                <div class="proimg">
                    <img src="<?php echo base_url(); ?>html/images/products/skin.jpg">
                </div>
                <div class="protitle hedbtn btn btn-1 btn-effect-1" data-direction="left">
                    <a href="<?php echo base_url(); ?>Category_List"><span>SKIN</span></a>
                </div>
            </div>
          </div>

          <div class="col s6 m2">
            <div class="probox">
                <div class="proimg">
                    <img src="<?php echo base_url(); ?>html/images/products/tattoo.jpg">
                </div>
                <div class="protitle btn hedbtn btn-1 btn-effect-1" data-direction="left">
                    <a href="<?php echo base_url(); ?>Category_List"><span>Tattoo</span></a>
                </div>
            </div>
          </div>

           <div class="col s6 m2">
            <div class="probox">
                <div class="proimg">
                    <img src="<?php echo base_url(); ?>html/images/products/combo.jpg">
                </div>
                <div class="protitle btn hedbtn btn-1 btn-effect-1" data-direction="left">
                    <a href="<?php echo base_url(); ?>Category_List"><span>combo</span></a>
                </div>
            </div>
          </div>

           <div class="col s6 m2">
            <div class="probox">
                <div class="proimg">
                    <img src="<?php echo base_url(); ?>html/images/products/gift.jpg">
                </div>
                <div class="protitle  hedbtn btn btn-1 btn-effect-1" data-direction="left">
                    <a href="<?php echo base_url(); ?>Category_List"><span>gift</span></a>
                </div>
            </div>
          </div>

           <div class="col s6 m2">
            <div class="probox">
                <div class="proimg">
                    <img src="<?php echo base_url(); ?>html/images/products/beard.jpg">
                </div>
                <div class="protitle btn hedbtn btn-1 btn-effect-1" data-direction="left">
                    <a href="<?php echo base_url(); ?>Category_List"><span>beard</span></a>
                </div>
            </div>
          </div>

    </div>
</div>
<!--=================================================end product part==========================-->


<!--=================================================Concerns part==========================-->
<div class="products" id="Concerns" >
    <div class="row">
          <div class="col s6 m2">
            <div class="probox">
                <div class="proimg">
                    <img src="<?php echo base_url(); ?>html/images/products/hai-fall.jpg">
                </div>
                <div class="protitle btn hedbtn btn-1 btn-effect-1" data-direction="left">
                    <a href="<?php echo base_url(); ?>Category_List"><span>hai-fall</span></a>
                </div>
            </div>
          </div>

           <div class="col s6 m2">
            <div class="probox">
                <div class="proimg">
                    <img src="<?php echo base_url(); ?>html/images/products/acne.jpg">
                </div>
                <div class="protitle btn hedbtn btn-1 btn-effect-1" data-direction="left">
                    <a href="<?php echo base_url(); ?>Category_List"><span>acne</span></a>
                </div>
            </div>
          </div>

      
    </div>
</div>
<!--=================================================end Concerns part==========================-->
<body>

<script type="text/javascript">
$("#productsa").mouseenter(function() {
      $("#products").fadeIn();
});
$("#products").mouseleave(function() {
      $("#products").fadeOut();
});


$("#Concernsa").mouseenter(function() {
      $("#Concerns").fadeIn();
});
$("#Concerns").mouseleave(function() {
      $("#Concerns").fadeOut();
});
</script>

<style type="text/css">
 a.brand-logo img {
       width: 108px;
    position: relative;
    top: 6px;
}
</style>
