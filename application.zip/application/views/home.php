<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.js"></script>
<div class="main">
	<div class="row hedrow">

		<div class="col s3 m3 wow rollIn" data-wow-duration="1s">
			<div class="itembox">
				<a href="#"><img src="<?php echo base_url(); ?>html/images/IMG1.png"></a>
				  <div class="itemname">
				   beard
			      </div>
			</div>
	    </div>

	    <div class="col s3 m3 wow rollIn" data-wow-duration="2s">
			<div class="itembox">
				<a href="#"><img src="<?php echo base_url(); ?>html/images/img3.png"></a>
				  <div class="itemname">
				   hair
			      </div>
			</div>
	    </div>

	    <div class="col s3 m3 wow rollIn" data-wow-duration="3s">
			<div class="itembox">
				<a href="#"><img src="<?php echo base_url(); ?>html/images/img2.png"></a>
				  <div class="itemname">
				   skin
			      </div>
			</div>
	    </div>

	    <div class="col s3 m3 wow rollIn" data-wow-duration="4s">
			<div class="itembox">
				<a href="#"><img src="<?php echo base_url(); ?>html/images/img4.png"></a>
				  <div class="itemname">
				   combo
			      </div>
			</div>
	    </div>

	</div>
</div>


<!--=================================slider========================================-->
<div class="homeslider">
	  <div class="carousel carousel-slider center homecar1">
		    <div class="carousel-item white-text" href="#one! ">
		     <img class="homeslideimg" src="<?php echo base_url(); ?>html/images/slide2.jpg">
		    </div>
		    <div class="carousel-item white-text" href="#two!">
		     <img class="homeslideimg" src="<?php echo base_url(); ?>html/images/slid4.jpg">
		    </div>
		    <div class="carousel-item white-text" href="#three!">
		       <img class="homeslideimg" src="<?php echo base_url(); ?>html/images/slide1.jpg">
		    </div>
		    <div class="carousel-item white-text" href="#four!">
		       <img class="homeslideimg" src="<?php echo base_url(); ?>html/images/slid4.jpg">
		    </div>
      </div>
</div>


<!--=================================2 black box slider========================================-->
     <div class="imgdes"  >
		<img class="wow slideInUp" data-wow-duration="2s" src="<?php echo base_url(); ?>html/images/ii.jpg">
	</div>
<div  class="boxsection">
	<div class="row brow">

		<div class="col s12 m6  wow fadeInLeft" data-wow-duration="2s" >
			<div class="bbox hoverable">
				<div class="blogoimg">
					<img src="<?php echo base_url(); ?>html/images/box1.jpg">
				</div>
				<div class="bname">
					refer & earn
				</div>
				<div class="bbutn">
					<a class="waves-effect waves-light btn btnstyle">refer</a>
				</div>
			</div>
		</div>

		<div class="col s12 m6 wow fadeInRight" data-wow-duration="2s" >
			<div class="bbox hoverable">
				<div class="blogoimg">
					<img src="<?php echo base_url(); ?>html/images/box1.jpg">
				</div>
				<div class="bname">
					refer & earn
				</div>
				<div class="bbutn">
					<a class="waves-effect waves-light btn btnstyle">refer</a>
				</div>
			</div>
		</div>

	</div>
</div>

<!--================================= men product ========================================-->
<div class="prosec">
	<div class="row">
		<div class="mprotitle">
			TOP SELLING MEN GROOMING PRODUCTS
		</div>
  <div class="customNavigation">
    <a class="btn gray prev"><i class="picon material-icons">chevron_left</i></a>
    <a class="btn gray next"><i class="picon material-icons">chevron_right</i></a>
  </div>


  <div id="slider-carousel" class="owl-carousel">

    <div class="item hoverable">
    	<div class="ii">
		      <a class="hoverfx" href="#">
		        <img src="<?php echo base_url(); ?>html/images/p1.jpg">
		      </a>
		</div>
	    <h4>Beardo Creme Power Styling Wax</h4>
	    <p class="ricee">Rs. 395</p>
    </div>

    <div class="item hoverable">
    	<div class="ii">
		      <a class="hoverfx" href="#">
		        <img src="<?php echo base_url(); ?>html/images/p1.jpg">
		      </a>
		</div>
	    <h4>Beardo Creme Power Styling Wax</h4>
	    <p class="ricee">Rs. 395</p>
    </div>


    <div class="item hoverable">
    	<div class="ii">
		      <a class="hoverfx" href="#">
		        <img src="<?php echo base_url(); ?>html/images/p1.jpg">
		      </a>
		</div>
	    <h4>Beardo Creme Power Styling Wax</h4>
	    <p class="ricee">Rs. 395</p>
    </div>


    <div class="item hoverable">
    	<div class="ii">
		      <a class="hoverfx" href="#">
		        <img src="<?php echo base_url(); ?>html/images/p1.jpg">
		      </a>
		</div>
	    <h4>Beardo Creme Power Styling Wax</h4>
	    <p class="ricee">Rs. 395</p>
    </div>

    <div class="item hoverable">
    	<div class="ii">
		      <a class="hoverfx" href="#">
		        <img src="<?php echo base_url(); ?>html/images/p1.jpg">
		      </a>
		</div>
	    <h4>Beardo Creme Power Styling Wax</h4>
	    <p class="ricee">Rs. 395</p>
    </div>

    <div class="item hoverable">
    	<div class="ii">
		      <a class="hoverfx" href="#">
		        <img src="<?php echo base_url(); ?>html/images/p1.jpg">
		      </a>
		</div>
	    <h4>Beardo Creme Power Styling Wax</h4>
	    <p class="ricee">Rs. 395</p>
    </div>

    <div class="item hoverable">
    	<div class="ii">
		      <a class="hoverfx" href="#">
		        <img src="<?php echo base_url(); ?>html/images/p1.jpg">
		      </a>
		</div>
	    <h4>Beardo Creme Power Styling Wax</h4>
	    <p class="ricee">Rs. 395</p>
    </div>

    <div class="item hoverable">
    	<div class="ii">
		      <a class="hoverfx" href="#">
		        <img src="<?php echo base_url(); ?>html/images/p1.jpg">
		      </a>
		</div>
	    <h4>Beardo Creme Power Styling Wax</h4>
	    <p class="ricee">Rs. 395</p>
    </div>

    <div class="item hoverable">
    	<div class="ii">
		      <a class="hoverfx" href="#">
		        <img src="<?php echo base_url(); ?>html/images/p1.jpg">
		      </a>
		</div>
	    <h4>Beardo Creme Power Styling Wax</h4>
	    <p class="ricee">Rs. 395</p>
    </div>

  </div>

</div>
</div>

<!--=================================CONCERNS slider=========================-->

<div class="consection">
	<div class="bacstyle wow bounceInLeft" data-wow-duration="4s">
		<div class="concertitle">
			CONCERNS
		</div>
		<div class="carousel carousel-slider center concercarrr">
	    
	    <div class="carousel-item white-text" href="#one!">
	     	<img src="<?php echo base_url(); ?>html/images/slide2.jpg">
	    </div>
	    <div class="carousel-item white-text" href="#two!">
	     <img src="<?php echo base_url(); ?>html/images/slid3.jpg">
	    </div>
	    <div class="carousel-item white-text" href="#three!">
	       <img src="<?php echo base_url(); ?>html/images/slid4.jpg">
	    </div>
	  </div>
	</div>
</div>

<!--=================================followers=========================-->
<div class="follsec">
</div>

<!--================================blog=============================-->
<div class="blogsec">
	<div class="subblogsec wow bounceInRight" data-wow-duration="4s">
		<div class="blogtitlee">
			blog
		</div>
		 <div class="carousel carousel-slider center blogcaruserl">
		    <div class="carousel-item  white-text" href="#one!">
		      <div class="row">
		      	  <div class="col s12 m6">
				      	<div class="bologboxx">
				      		<div class="bimg">
				      			<img src="<?php echo base_url(); ?>html/images/b1.jpg">
				      	    </div>
				      	    <div class="bogcon">
				      	    	Sun Is Out, Skin Is In
				      	    </div>
				      	    <div class="blogbtn">
				      	    	<a class="waves-effect waves-light blogbtnstyle btn">button</a>
				      	    </div>
				      	</div>
			      </div>
			       <div class="col s12 m6">
				      	<div class="bologboxx">
				      		<div class="bimg">
				      			<img src="<?php echo base_url(); ?>html/images/b2.jpg">
				      	    </div>
				      	    <div class="bogcon">
				      	    	Sun Is Out, Skin Is In
				      	    </div>
				      	    <div class="blogbtn">
				      	    	<a class="waves-effect waves-light blogbtnstyle btn">button</a>
				      	    </div>
				      	</div>
			      </div>
		      </div>
		    </div>
		    <div class="carousel-item amber white-text" href="#two!">
		      <h2>Second Panel</h2>
		      <p class="white-text">This is your second panel</p>
		    </div>
		  </div>
    </div>
</div>

<!--==============================signupdiv============================-->
<div class="sec">
	<div class="maincon">
		Sign up to get 50 reward points and use it from your first purchase
	</div>
	<div class="subcon">
		* Get Reward points every purchase and use it in your next purchase
	</div>
</div>





