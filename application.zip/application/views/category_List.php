<div class="topnav" id="myTopnav">
<div class="col-sm-8 subptotitle" style="text-align:center;">
  <a  href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="myFunction()">&#9776;</a>
  <a href="#home" class="active">HAIR</a>
  <a href="#blog">SKIN</a>
  <a href="#contact">Tattoo</a>
  <a href="#about">combo</a>
  <a href="#about">gift</a>
  <a href="#about">beard</a>

</div>
</div>

<div class="container prolistcon">
  <div class="row">
<div class="protitle">
  products
</div>
  <div class=" col s12 m6 ">
    <div class="product">
    <div class="img-container">
      <img src="https://images.unsplash.com/photo-1491553895911-0055eca6402d?dpr=1&auto=compress,format&fit=crop&w=1400&h=&q=80&cs=tinysrgb&crop=">
    </div>
    <div class="product-info">
      <div class="product-content">
        <h1>Nike Airmax</h1>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit ariatur</p>
        <ul>
          <li>Lorem ipsum dolor sit ametconsectetu.</li>
          <li>adipisicing elit dlanditiis quis ip.</li>
          <li>lorem sde glanditiis dars fao.</li>
        </ul>
        <div class="buttons">
          <a class="button buy" href="<?php echo base_url(); ?>Category_details">View Details</a>
          <a class="button add" href="<?php echo base_url(); ?>Category_details">Add to Cart</a>
          <span class="button" id="price">$59,99</span>
        </div>

         <div class="buttons">
          <i style="color: rgba(232, 19, 165, 0.45);" class="fas fa-heart wow flip" data-wow-duration="2s"></i>
          <i style="color: rgba(255, 217, 19, 0.47);" class="fas fa-briefcase  wow flip" data-wow-duration="2s"></i>
         <i  style="color: #0080007a;" class="fas fa-sync-alt wow flip" data-wow-duration="2s"></i>
        </div>
      </div>
    </div>
  </div>
  </div>
  
  <div class=" col s12 m6 ">
    <div class="product">
    <div class="img-container">
      <img src="https://images.unsplash.com/photo-1434493907317-a46b5bbe7834?dpr=1&auto=compress,format&fit=crop&w=1500&h=&q=80&cs=tinysrgb&crop=">
    </div>
    <div class="product-info">
      <div class="product-content">
        <h1>Apple Watch 3</h1>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit ariatur</p>
        <ul>
          <li>Lorem ipsum dolor sit ametconsectetu.</li>
          <li>adipisicing elit dlanditiis quis ip.</li>
          <li>lorem sde glanditiis dars fao.</li>
        </ul>
        <div class="buttons">
          <a class="button buy" href="<?php echo base_url(); ?>Category_details">View Details</a>
          <a class="button add" href="<?php echo base_url(); ?>Category_details">Add to Cart</a>
          <span class="button" id="price">$120,99</span>
        </div>

        <div class="buttons">
          <i style="color: rgba(232, 19, 165, 0.45);" class="fas fa-heart wow flip" data-wow-duration="2s"></i>
          <i style="color: rgba(255, 217, 19, 0.47);" class="fas fa-briefcase  wow flip" data-wow-duration="2s"></i>
         <i  style="color: #0080007a;" class="fas fa-sync-alt wow flip" data-wow-duration="2s"></i>
        </div>
      </div>
    </div>
  </div>
</div>



  <div class=" col s12 m6 ">
    <div class="product">
    <div class="img-container">
      <img src="https://images.unsplash.com/photo-1491553895911-0055eca6402d?dpr=1&auto=compress,format&fit=crop&w=1400&h=&q=80&cs=tinysrgb&crop=">
    </div>
    <div class="product-info">
      <div class="product-content">
        <h1>Nike Airmax</h1>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit ariatur</p>
        <ul>
          <li>Lorem ipsum dolor sit ametconsectetu.</li>
          <li>adipisicing elit dlanditiis quis ip.</li>
          <li>lorem sde glanditiis dars fao.</li>
        </ul>
        <div class="buttons">
          <a class="button buy" href="<?php echo base_url(); ?>Category_details">View Details</a>
          <a class="button add" href="<?php echo base_url(); ?>Category_details">Add to Cart</a>
          <span class="button" id="price">$59,99</span>
        </div>

        <div class="buttons">
          <i style="color: rgba(232, 19, 165, 0.45);" class="fas fa-heart wow flip" data-wow-duration="2s"></i>
          <i style="color: rgba(255, 217, 19, 0.47);" class="fas fa-briefcase  wow flip" data-wow-duration="2s"></i>
         <i  style="color: #0080007a;" class="fas fa-sync-alt wow flip" data-wow-duration="2s"></i>
        </div>
      </div>
    </div>
  </div>
  </div>
  
  <div class=" col s12 m6 ">
    <div class="product">
    <div class="img-container">
      <img src="https://images.unsplash.com/photo-1434493907317-a46b5bbe7834?dpr=1&auto=compress,format&fit=crop&w=1500&h=&q=80&cs=tinysrgb&crop=">
    </div>
    <div class="product-info">
      <div class="product-content">
        <h1>Apple Watch 3</h1>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit ariatur</p>
        <ul>
          <li>Lorem ipsum dolor sit ametconsectetu.</li>
          <li>adipisicing elit dlanditiis quis ip.</li>
          <li>lorem sde glanditiis dars fao.</li>
        </ul>
        <div class="buttons">
           <a class="button buy" href="<?php echo base_url(); ?>Category_details">View Details</a>
          <a class="button add" href="<?php echo base_url(); ?>Category_details">Add to Cart</a>
          <span class="button" id="price">$120,99</span>
        </div>

        <div class="buttons">
          <i style="color: rgba(232, 19, 165, 0.45);" class="fas fa-heart wow flip" data-wow-duration="2s"></i>
          <i style="color: rgba(255, 217, 19, 0.47);" class="fas fa-briefcase  wow flip" data-wow-duration="2s"></i>
         <i  style="color: #0080007a;" class="fas fa-sync-alt wow flip" data-wow-duration="2s"></i>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
  
</div>

<style type="text/css">
 

</style>